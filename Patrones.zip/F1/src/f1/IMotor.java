
package f1;

/**
 *
 * @author nmh14
 */
public interface IMotor {
    public void encenderMotor(int velocidad);
    public void mostrarTipoDeMotor();
}



