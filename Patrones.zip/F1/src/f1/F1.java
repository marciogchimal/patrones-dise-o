/*
package f1;

/**
 *
 * @author nmh14
 */
/*
public class F1 {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        IMotor motorHonda = new Honda();
        Equipo equipoRB = new EquipoRedBull(motorHonda);
        equipoRB.obtenerVelocidad(397);
        equipoRB.caracteristicasDeEquipo();
        
        IMotor motorFerrari = new Ferrari();
        Equipo equipoRBPrueba2 = new EquipoRedBull(motorFerrari);
        equipoRBPrueba2.obtenerVelocidad(355);
        equipoRBPrueba2.caracteristicasDeEquipo();
    }
    
}
*/